const express = require('express');
const router = express.Router();

router.get('/', (req, res, next) => {
	return res.render('index.ejs');
});
router.get('/aishwaryamone', (req, res, next) => {
	return res.render('single-project-1.ejs');
});
router.get('/aishwaryamhamara', (req, res, next) => {
 
	return res.render('single-project-2.ejs');
});
router.get('/aishwaryamcoutyard2', (req, res, next) => {
 
	return res.render('single-project-3.ejs');
});
router.get('/aishwaryamniwara', (req, res, next) => {
 
	return res.render('single-project-4.ejs');
});
router.get('/aishwaryamnature', (req, res, next) => {
 
	return res.render('single-project-5.ejs');
});


module.exports = router;